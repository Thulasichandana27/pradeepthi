package com.oto.authenticationservice2.dto;

import com.oto.authenticationservice2.model.Role;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.Set;

public record CustomerRequest(
        Long id,
        @NotEmpty(message = "First Name is required")
        String firstName,
        @NotEmpty(message = "Last Name is required")
        String lastName,
        @Email(message = "Email is not valid")
        @NotEmpty(message = "Email is required")
        String email,
        @NotEmpty(message = "Username is required")
        String username,
        @NotEmpty(message = "Password is required")
        String password,
        @NotNull(message = "role is required")
        Set<Role> roles
) {
}
