package com.oto.authenticationservice2.service;

import com.oto.authenticationservice2.dto.CustomerRequest;
import com.oto.authenticationservice2.dto.LoginRequest;
import com.oto.authenticationservice2.jwt.JwtUtil;
import com.oto.authenticationservice2.model.Customer;
import com.oto.authenticationservice2.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    @Override
    public String createCustomer(CustomerRequest customerRequest) {
        var customer=customerRepository.save(Customer.builder()
                .password(passwordEncoder.encode(customerRequest.password()))
                .username(customerRequest.username())
                .roles(customerRequest.roles())
                .email(customerRequest.email())
                .firstName(customerRequest.firstName())
                .lastName(customerRequest.lastName())
                .build());
        return "Customer created with ID ::"+customer.getId();
    }

    @Override
    public String login(LoginRequest loginRequest) {

        UsernamePasswordAuthenticationToken token=new UsernamePasswordAuthenticationToken(loginRequest.username(), loginRequest.password());
        var authentication=authenticationManager.authenticate(token);
        var isValid=authentication.isAuthenticated();
        if(isValid){
            return jwtUtil.generateToken(loginRequest.username());
        }
        return "Login Failed";
    }
}
