package com.oto.authenticationservice2.service;

import com.oto.authenticationservice2.dto.CustomerRequest;
import com.oto.authenticationservice2.dto.LoginRequest;
import jakarta.validation.Valid;

public interface CustomerService {
    String createCustomer(CustomerRequest customerRequest);

    String login(LoginRequest loginRequest);
}
