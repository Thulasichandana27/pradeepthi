package com.oto.authenticationservice2.exception;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Set;
import java.util.stream.Collectors;

@RestControllerAdvice
public class CustomGlobalException {

    @ExceptionHandler({MethodArgumentNotValidException.class})
    public ResponseEntity handleMethodArgumentNotValid(MethodArgumentNotValidException ex, BindingResult bindingResult) {
      Set<String> errors=  ex.getBindingResult().getAllErrors().stream().map(error->error.getDefaultMessage()).collect(Collectors.toSet());
      return new ResponseEntity(errors, HttpStatusCode.valueOf(500));
    }

}
