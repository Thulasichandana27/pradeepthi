package com.oto.authenticationservice2.model;

public enum Role {
    ADMIN,CUSTOMER,SUPER_ADMIN
}
