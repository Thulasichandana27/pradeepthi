package com.oto.authenticationservice2.service;

import com.oto.authenticationservice2.model.Customer;
import com.oto.authenticationservice2.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MyUserDetailsService implements UserDetailsService {

    private final CustomerRepository customerRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Customer> opt=customerRepository.findByUsername(username);
        if(opt.isEmpty()){
            throw new UsernameNotFoundException("user not found");
        }
        Customer customer=opt.get();
        User user=new User(customer.getUsername(),customer.getPassword(),
                customer.getRoles().stream().map(role->new SimpleGrantedAuthority(role.toString())).collect(Collectors.toSet()));
        return user;
    }
}
