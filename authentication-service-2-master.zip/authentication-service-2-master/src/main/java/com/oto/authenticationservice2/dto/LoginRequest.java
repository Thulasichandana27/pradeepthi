package com.oto.authenticationservice2.dto;

import jakarta.validation.constraints.NotEmpty;

public record LoginRequest(
        @NotEmpty(message = "username is required")
        String username,
        @NotEmpty(message = "password is required")
        String password) {
}
