package com.oto.authenticationservice2.controller;

import com.oto.authenticationservice2.dto.CustomerRequest;
import com.oto.authenticationservice2.dto.LoginRequest;
import com.oto.authenticationservice2.model.Customer;
import com.oto.authenticationservice2.service.CustomerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/v1/api/customer")
@RequiredArgsConstructor
public class CustomerController {



    private final CustomerService customerService;

    @PostMapping(value = "/register")
    public ResponseEntity<String> addCustomer(@RequestBody @Valid CustomerRequest customerRequest) {
        var msg=customerService.createCustomer(customerRequest);
        return new ResponseEntity<String>(msg, HttpStatusCode.valueOf(201));
    }

    @PostMapping(value = "/login")
    public ResponseEntity<String> login(@RequestBody @Valid LoginRequest loginRequest) {
        var msg=customerService.login(loginRequest);
        return new ResponseEntity<>(msg, HttpStatusCode.valueOf(201));
    }


    @GetMapping
    public String welcome(){
        return "Welcome to  Authentication Service";
    }

}
