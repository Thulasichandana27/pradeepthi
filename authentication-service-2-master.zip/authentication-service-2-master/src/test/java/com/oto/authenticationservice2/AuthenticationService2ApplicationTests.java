package com.oto.authenticationservice2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationService2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
