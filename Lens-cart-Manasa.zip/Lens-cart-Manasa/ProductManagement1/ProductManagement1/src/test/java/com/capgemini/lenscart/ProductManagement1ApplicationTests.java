package com.capgemini.lenscart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
