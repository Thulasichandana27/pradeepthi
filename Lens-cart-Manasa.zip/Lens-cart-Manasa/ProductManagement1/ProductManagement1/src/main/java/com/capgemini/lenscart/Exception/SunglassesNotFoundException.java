package com.capgemini.lenscart.Exception;

public class SunglassesNotFoundException extends RuntimeException {
    public SunglassesNotFoundException(String message) {
        super(message);
    }
}
