package com.capgemini.lenscart.Exception;

//Custom Exception for Not Found Frame
public class FrameNotFoundException extends RuntimeException {
	public FrameNotFoundException(String msg) {
		super(msg);
	}

 
}


