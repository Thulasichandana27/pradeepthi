package com.capgemini.lenscart.Exception;

public class GlassNotFoundException extends RuntimeException {
    public GlassNotFoundException(String message) {
        super(message);
    }
}
