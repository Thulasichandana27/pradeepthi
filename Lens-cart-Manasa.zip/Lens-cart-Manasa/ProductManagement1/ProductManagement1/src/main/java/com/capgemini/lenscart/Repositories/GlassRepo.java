package com.capgemini.lenscart.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.lenscart.entities.Glass;

public interface GlassRepo extends JpaRepository<Glass,Long>{

}
